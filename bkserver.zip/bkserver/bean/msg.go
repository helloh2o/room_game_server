package bean

type Msg struct {
	Player *Player
	Raw    []byte //　原始数据
}
