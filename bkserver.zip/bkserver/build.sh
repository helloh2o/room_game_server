go build main.go
killall debug_main
cp main debug/debug_main
echo "ok"
