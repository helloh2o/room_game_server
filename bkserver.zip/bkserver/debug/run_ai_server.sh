nohup ./ai_server -auto false -max 3000 -root "/root/golang/src/server/ai/lua/root.lua" &
