nohup ./debug_main &
