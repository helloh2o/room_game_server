protoc  -o gameserver.pb gameserver.proto
