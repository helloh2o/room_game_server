  
local uuid = require("uuid4")

print(uuid.getUUID())
print(uuid.getUUID())
