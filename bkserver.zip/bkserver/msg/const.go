package msg

const (
	// 房间消息
	G_enter_room   = uint32(0x101)
	G_full_room    = uint32(0x102)
	G_leave_room   = uint32(0x103)
	G_kickout_room = uint32(0x104)
	Glayer_offline = uint32(0x105)
)
