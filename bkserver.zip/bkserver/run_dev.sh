nohup go run main.go &
#nohup ./debug_main &
