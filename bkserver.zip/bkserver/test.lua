DEBUG = false
print(DEBUG)
